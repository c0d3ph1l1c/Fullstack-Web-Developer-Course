const path = require('path');

let str = '/root/a/b/1.txt';

// console.log(path.dirname(str));
// console.log(path.extname(str));
// console.log(path.basename(str));

// console.log(path.resolve('/root/a/b', '../c', 'build', '..', 'strict'));

console.log(path.resolve(__dirname, 'build'));

