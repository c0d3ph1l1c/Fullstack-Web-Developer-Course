const assert = require('assert');

assert(5<3, 'aaa');

// assert.deepEqual(actual, expected, msg);
// assert.deepStrictEqual(actual, expected, msg);